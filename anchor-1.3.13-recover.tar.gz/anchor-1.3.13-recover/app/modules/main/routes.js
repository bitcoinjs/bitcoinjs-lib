/* eslint flowtype-errors/show-errors: 0 */
import React from 'react';

import MainIndexContainer from '../../modules/main/containers/Index';

export default () => <MainIndexContainer />;
